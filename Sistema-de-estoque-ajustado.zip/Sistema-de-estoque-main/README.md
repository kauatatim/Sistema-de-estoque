# Sistema Digital de Gestao de Materiais e Eventos

Projeto em NestJS, TypeScript, HTML, CSS e MySQL para auxiliar uma escola tecnica no controle de materiais/equipamentos e na divulgacao de eventos, prazos e oportunidades.

## Funcionalidades

- Cadastro e listagem de usuarios por perfil: aluno, professor, pedagogo e diretor.
- Login com senha criptografada e token JWT.
- Cadastro, listagem, edicao e remocao de categorias.
- Cadastro, listagem, edicao e remocao de equipamentos.
- Solicitacao, aprovacao, rejeicao e devolucao de emprestimos.
- Calendario de eventos, prazos e oportunidades.
- Interface web simples em HTML/CSS/JS disponivel em `http://localhost:3000`.

## Como rodar

1. Instale as dependencias:

```bash
npm install
```

2. Importe o banco no MySQL:

```bash
mysql -u root -p < schema.sql
```

3. Confira a senha do MySQL em `src/app.module.ts`.

4. Inicie o projeto:

```bash
npm run start:dev
```

## Rotas principais

- `POST /users`, `GET /users`, `GET /users/:id`
- `POST /auth/login`
- `POST /categorias`, `GET /categorias`, `PATCH /categorias/:id`, `DELETE /categorias/:id`
- `POST /equipamentos`, `GET /equipamentos`, `PATCH /equipamentos/:id`, `DELETE /equipamentos/:id`
- `POST /emprestimos`, `GET /emprestimos`, `PATCH /emprestimos/:id/aprovar`, `PATCH /emprestimos/:id/rejeitar`, `PATCH /emprestimos/:id/devolver`
- `POST /eventos`, `GET /eventos`, `PATCH /eventos/:id`, `DELETE /eventos/:id`

## Observacao

Os usuarios de exemplo no SQL possuem hashes demonstrativos. Para testar login de verdade, cadastre um novo usuario pela rota `POST /users` ou pela ferramenta de API usada pelo grupo.
