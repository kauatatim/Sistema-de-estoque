import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Equipamento } from './equipamento.entity';

@Injectable()
export class EquipamentosService {
  constructor(
    @InjectRepository(Equipamento)
    private equipamentosRepo: Repository<Equipamento>,
  ) {}

  async criar(dto: any): Promise<Equipamento> {
    const existe = await this.equipamentosRepo.findOne({ where: { codigoPatrimonio: dto.codigoPatrimonio } });
    if (existe) throw new ConflictException('Codigo de patrimonio ja cadastrado.');
    const equipamento = this.equipamentosRepo.create({
      nome: dto.nome,
      categoriaId: Number(dto.categoriaId),
      codigoPatrimonio: dto.codigoPatrimonio,
      status: dto.status ?? 'DISPONIVEL',
      cadastradoPorId: Number(dto.cadastradoPorId),
      atualizadoPorId: dto.atualizadoPorId ? Number(dto.atualizadoPorId) : null,
    });
    return this.equipamentosRepo.save(equipamento);
  }

  listar(status?: string): Promise<Equipamento[]> {
    return this.equipamentosRepo.find({ where: status ? { status } : {}, order: { nome: 'ASC' } });
  }

  async buscarPorId(id: number): Promise<Equipamento> {
    const equipamento = await this.equipamentosRepo.findOne({ where: { id } });
    if (!equipamento) throw new NotFoundException('Equipamento nao encontrado.');
    return equipamento;
  }

  async atualizar(id: number, dto: any): Promise<Equipamento> {
    const equipamento = await this.buscarPorId(id);
    equipamento.nome = dto.nome ?? equipamento.nome;
    equipamento.categoriaId = dto.categoriaId ? Number(dto.categoriaId) : equipamento.categoriaId;
    equipamento.codigoPatrimonio = dto.codigoPatrimonio ?? equipamento.codigoPatrimonio;
    equipamento.status = dto.status ?? equipamento.status;
    equipamento.atualizadoPorId = dto.atualizadoPorId ? Number(dto.atualizadoPorId) : equipamento.atualizadoPorId;
    return this.equipamentosRepo.save(equipamento);
  }

  async alterarStatus(id: number, status: string): Promise<Equipamento> {
    const equipamento = await this.buscarPorId(id);
    equipamento.status = status;
    return this.equipamentosRepo.save(equipamento);
  }

  async remover(id: number): Promise<{ mensagem: string }> {
    await this.buscarPorId(id);
    await this.equipamentosRepo.delete(id);
    return { mensagem: 'Equipamento removido com sucesso.' };
  }
}
