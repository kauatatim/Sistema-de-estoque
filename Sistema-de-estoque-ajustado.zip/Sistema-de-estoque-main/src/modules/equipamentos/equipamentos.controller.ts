import { Body, Controller, Delete, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { EquipamentosService } from './equipamentos.service';

@Controller('equipamentos')
export class EquipamentosController {
  constructor(private readonly equipamentosService: EquipamentosService) {}

  @Post()
  criar(@Body() dto: any) { return this.equipamentosService.criar(dto); }

  @Get()
  listar(@Query('status') status?: string) { return this.equipamentosService.listar(status); }

  @Get(':id')
  buscar(@Param('id') id: string) { return this.equipamentosService.buscarPorId(Number(id)); }

  @Patch(':id')
  atualizar(@Param('id') id: string, @Body() dto: any) { return this.equipamentosService.atualizar(Number(id), dto); }

  @Delete(':id')
  remover(@Param('id') id: string) { return this.equipamentosService.remover(Number(id)); }
}
