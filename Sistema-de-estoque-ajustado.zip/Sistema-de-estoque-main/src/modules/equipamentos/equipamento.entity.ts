import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { Categoria } from '../Users/categorias/categoria.entity';
import { User } from '../Users/user.entity';

@Entity('equipamento')
export class Equipamento {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 150 })
  nome: string;

  @ManyToOne(() => Categoria, { eager: true })
  @JoinColumn({ name: 'categoria_id' })
  categoria: Categoria;

  @Column({ name: 'categoria_id' })
  categoriaId: number;

  @Column({ name: 'codigo_patrimonio', length: 50, unique: true })
  codigoPatrimonio: string;

  @Column({ type: 'enum', enum: ['DISPONIVEL', 'EMPRESTADO', 'MANUTENCAO'], default: 'DISPONIVEL' })
  status: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'cadastrado_por' })
  cadastradoPor: User;

  @Column({ name: 'cadastrado_por' })
  cadastradoPorId: number;

  @CreateDateColumn({ name: 'data_cadastro' })
  dataCadastro: Date;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn({ name: 'atualizado_por' })
  atualizadoPor: User;

  @Column({ name: 'atualizado_por', nullable: true })
  atualizadoPorId: number;

  @UpdateDateColumn({ name: 'data_atualizacao', nullable: true })
  dataAtualizacao: Date;
}
