import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Categoria } from './categoria.entity';

@Injectable()
export class CategoriasService {
  constructor(
    @InjectRepository(Categoria)
    private categoriasRepo: Repository<Categoria>,
  ) {}

  async criar(dto: any): Promise<Categoria> {
    const existe = await this.categoriasRepo.findOne({ where: { nome: dto.nome } });
    if (existe) throw new ConflictException('Categoria ja cadastrada.');
    return this.categoriasRepo.save(this.categoriasRepo.create({ nome: dto.nome }));
  }

  listar(): Promise<Categoria[]> {
    return this.categoriasRepo.find({ order: { nome: 'ASC' } });
  }

  async buscarPorId(id: number): Promise<Categoria> {
    const categoria = await this.categoriasRepo.findOne({ where: { id } });
    if (!categoria) throw new NotFoundException('Categoria nao encontrada.');
    return categoria;
  }

  async atualizar(id: number, dto: any): Promise<Categoria> {
    const categoria = await this.buscarPorId(id);
    categoria.nome = dto.nome ?? categoria.nome;
    return this.categoriasRepo.save(categoria);
  }

  async remover(id: number): Promise<{ mensagem: string }> {
    await this.buscarPorId(id);
    await this.categoriasRepo.delete(id);
    return { mensagem: 'Categoria removida com sucesso.' };
  }
}
