import { Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { CategoriasService } from './categorias.service';

@Controller('categorias')
export class CategoriasController {
  constructor(private readonly categoriasService: CategoriasService) {}

  @Post()
  criar(@Body() dto: any) {
    return this.categoriasService.criar(dto);
  }

  @Get()
  listar() {
    return this.categoriasService.listar();
  }

  @Get(':id')
  buscar(@Param('id') id: string) {
    return this.categoriasService.buscarPorId(Number(id));
  }

  @Patch(':id')
  atualizar(@Param('id') id: string, @Body() dto: any) {
    return this.categoriasService.atualizar(Number(id), dto);
  }

  @Delete(':id')
  remover(@Param('id') id: string) {
    return this.categoriasService.remover(Number(id));
  }
}
