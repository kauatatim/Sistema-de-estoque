import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('categoria_equipamento')
export class Categoria {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 60, unique: true })
  nome: string;
}
