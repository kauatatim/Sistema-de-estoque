import { Body, Controller, Delete, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { EventosService } from './eventos.service';

@Controller('eventos')
export class EventosController {
  constructor(private readonly eventosService: EventosService) {}

  @Post()
  criar(@Body() dto: any) { return this.eventosService.criar(dto); }

  @Get()
  listar(@Query('tipo') tipo?: string) { return this.eventosService.listar(tipo); }

  @Get(':id')
  buscar(@Param('id') id: string) { return this.eventosService.buscarPorId(Number(id)); }

  @Patch(':id')
  atualizar(@Param('id') id: string, @Body() dto: any) { return this.eventosService.atualizar(Number(id), dto); }

  @Delete(':id')
  remover(@Param('id') id: string) { return this.eventosService.remover(Number(id)); }
}
