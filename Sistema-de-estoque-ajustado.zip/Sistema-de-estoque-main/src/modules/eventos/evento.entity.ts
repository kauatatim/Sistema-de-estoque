import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { User } from '../Users/user.entity';

@Entity('evento')
export class Evento {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 150 })
  titulo: string;

  @Column({ type: 'text', nullable: true })
  descricao: string;

  @Column({ name: 'data_inicio' })
  dataInicio: Date;

  @Column({ name: 'data_fim', nullable: true })
  dataFim: Date;

  @Column({ type: 'enum', enum: ['EVENTO', 'PRAZO', 'OPORTUNIDADE'], default: 'EVENTO' })
  tipo: string;

  @Column({ length: 120, nullable: true })
  local: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'criado_por' })
  criadoPor: User;

  @Column({ name: 'criado_por' })
  criadoPorId: number;

  @CreateDateColumn({ name: 'data_cadastro' })
  dataCadastro: Date;
}
