import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Evento } from './evento.entity';

@Injectable()
export class EventosService {
  constructor(
    @InjectRepository(Evento)
    private eventosRepo: Repository<Evento>,
  ) {}

  criar(dto: any): Promise<Evento> {
    const evento = this.eventosRepo.create({
      titulo: dto.titulo,
      descricao: dto.descricao,
      dataInicio: new Date(dto.dataInicio),
      dataFim: dto.dataFim ? new Date(dto.dataFim) : null,
      tipo: dto.tipo ?? 'EVENTO',
      local: dto.local,
      criadoPorId: Number(dto.criadoPorId),
    });
    return this.eventosRepo.save(evento);
  }

  listar(tipo?: string): Promise<Evento[]> {
    return this.eventosRepo.find({ where: tipo ? { tipo } : {}, order: { dataInicio: 'ASC' } });
  }

  async buscarPorId(id: number): Promise<Evento> {
    const evento = await this.eventosRepo.findOne({ where: { id } });
    if (!evento) throw new NotFoundException('Evento nao encontrado.');
    return evento;
  }

  async atualizar(id: number, dto: any): Promise<Evento> {
    const evento = await this.buscarPorId(id);
    evento.titulo = dto.titulo ?? evento.titulo;
    evento.descricao = dto.descricao ?? evento.descricao;
    evento.dataInicio = dto.dataInicio ? new Date(dto.dataInicio) : evento.dataInicio;
    evento.dataFim = dto.dataFim ? new Date(dto.dataFim) : evento.dataFim;
    evento.tipo = dto.tipo ?? evento.tipo;
    evento.local = dto.local ?? evento.local;
    return this.eventosRepo.save(evento);
  }

  async remover(id: number): Promise<{ mensagem: string }> {
    await this.buscarPorId(id);
    await this.eventosRepo.delete(id);
    return { mensagem: 'Evento removido com sucesso.' };
  }
}
