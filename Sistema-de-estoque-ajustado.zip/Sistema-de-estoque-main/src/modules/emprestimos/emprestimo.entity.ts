import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Equipamento } from '../equipamentos/equipamento.entity';
import { User } from '../Users/user.entity';

@Entity('emprestimo')
export class Emprestimo {
  @PrimaryGeneratedColumn()
  id: number;

  @CreateDateColumn({ name: 'data_solicitacao' })
  dataSolicitacao: Date;

  @Column({ name: 'data_devolucao_prevista', nullable: true })
  dataDevolucaoPrevista: Date;

  @Column({ name: 'data_devolucao_real', nullable: true })
  dataDevolucaoReal: Date;

  @Column({ type: 'enum', enum: ['PENDENTE', 'APROVADO', 'REJEITADO', 'DEVOLVIDO'], default: 'PENDENTE' })
  status: string;

  @ManyToOne(() => User, { eager: true })
  @JoinColumn({ name: 'usuario_id' })
  usuario: User;

  @Column({ name: 'usuario_id' })
  usuarioId: number;

  @ManyToOne(() => Equipamento, { eager: true })
  @JoinColumn({ name: 'equipamento_id' })
  equipamento: Equipamento;

  @Column({ name: 'equipamento_id' })
  equipamentoId: number;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn({ name: 'aprovado_por' })
  aprovadoPor: User;

  @Column({ name: 'aprovado_por', nullable: true })
  aprovadoPorId: number;
}
