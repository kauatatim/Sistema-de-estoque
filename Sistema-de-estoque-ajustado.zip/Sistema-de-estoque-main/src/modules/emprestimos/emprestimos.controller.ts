import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { EmprestimosService } from './emprestimos.service';

@Controller('emprestimos')
export class EmprestimosController {
  constructor(private readonly emprestimosService: EmprestimosService) {}

  @Post()
  solicitar(@Body() dto: any) { return this.emprestimosService.solicitar(dto); }

  @Get()
  listar(@Query('status') status?: string) { return this.emprestimosService.listar(status); }

  @Get(':id')
  buscar(@Param('id') id: string) { return this.emprestimosService.buscarPorId(Number(id)); }

  @Patch(':id/aprovar')
  aprovar(@Param('id') id: string, @Body() dto: any) { return this.emprestimosService.aprovar(Number(id), dto); }

  @Patch(':id/rejeitar')
  rejeitar(@Param('id') id: string, @Body() dto: any) { return this.emprestimosService.rejeitar(Number(id), dto); }

  @Patch(':id/devolver')
  devolver(@Param('id') id: string) { return this.emprestimosService.devolver(Number(id)); }
}
