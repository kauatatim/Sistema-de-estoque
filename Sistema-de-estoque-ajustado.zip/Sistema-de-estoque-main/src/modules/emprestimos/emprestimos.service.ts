import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { EquipamentosService } from '../equipamentos/equipamentos.service';
import { Emprestimo } from './emprestimo.entity';

@Injectable()
export class EmprestimosService {
  constructor(
    @InjectRepository(Emprestimo)
    private emprestimosRepo: Repository<Emprestimo>,
    private equipamentosService: EquipamentosService,
  ) {}

  async solicitar(dto: any): Promise<Emprestimo> {
    const equipamento = await this.equipamentosService.buscarPorId(Number(dto.equipamentoId));
    if (equipamento.status !== 'DISPONIVEL') throw new BadRequestException('Equipamento nao esta disponivel.');
    const emprestimo = this.emprestimosRepo.create({
      usuarioId: Number(dto.usuarioId),
      equipamentoId: Number(dto.equipamentoId),
      dataDevolucaoPrevista: dto.dataDevolucaoPrevista ? new Date(dto.dataDevolucaoPrevista) : null,
    });
    return this.emprestimosRepo.save(emprestimo);
  }

  listar(status?: string): Promise<Emprestimo[]> {
    return this.emprestimosRepo.find({ where: status ? { status } : {}, order: { dataSolicitacao: 'DESC' } });
  }

  async buscarPorId(id: number): Promise<Emprestimo> {
    const emprestimo = await this.emprestimosRepo.findOne({ where: { id } });
    if (!emprestimo) throw new NotFoundException('Emprestimo nao encontrado.');
    return emprestimo;
  }

  async aprovar(id: number, dto: any): Promise<Emprestimo> {
    const emprestimo = await this.buscarPorId(id);
    if (emprestimo.status !== 'PENDENTE') throw new BadRequestException('Somente solicitacoes pendentes podem ser aprovadas.');
    emprestimo.status = 'APROVADO';
    emprestimo.aprovadoPorId = Number(dto.aprovadoPorId);
    emprestimo.dataDevolucaoPrevista = dto.dataDevolucaoPrevista ? new Date(dto.dataDevolucaoPrevista) : emprestimo.dataDevolucaoPrevista;
    await this.equipamentosService.alterarStatus(emprestimo.equipamentoId, 'EMPRESTADO');
    return this.emprestimosRepo.save(emprestimo);
  }

  async rejeitar(id: number, dto: any): Promise<Emprestimo> {
    const emprestimo = await this.buscarPorId(id);
    emprestimo.status = 'REJEITADO';
    emprestimo.aprovadoPorId = dto.aprovadoPorId ? Number(dto.aprovadoPorId) : emprestimo.aprovadoPorId;
    await this.equipamentosService.alterarStatus(emprestimo.equipamentoId, 'DISPONIVEL');
    return this.emprestimosRepo.save(emprestimo);
  }

  async devolver(id: number): Promise<Emprestimo> {
    const emprestimo = await this.buscarPorId(id);
    if (emprestimo.status !== 'APROVADO') throw new BadRequestException('Somente emprestimos aprovados podem ser devolvidos.');
    emprestimo.status = 'DEVOLVIDO';
    emprestimo.dataDevolucaoReal = new Date();
    await this.equipamentosService.alterarStatus(emprestimo.equipamentoId, 'DISPONIVEL');
    return this.emprestimosRepo.save(emprestimo);
  }
}
