import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EquipamentosModule } from '../equipamentos/equipamentos.module';
import { Emprestimo } from './emprestimo.entity';
import { EmprestimosController } from './emprestimos.controller';
import { EmprestimosService } from './emprestimos.service';

@Module({
  imports: [TypeOrmModule.forFeature([Emprestimo]), EquipamentosModule],
  controllers: [EmprestimosController],
  providers: [EmprestimosService],
})
export class EmprestimosModule {}
