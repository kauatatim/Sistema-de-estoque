import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './modules/Users/users.module';
import { AuthModule } from './modules/Users/auth/auth.module';
import { CategoriasModule } from './modules/Users/categorias/categorias.module';
import { EquipamentosModule } from './modules/equipamentos/equipamentos.module';
import { EmprestimosModule } from './modules/emprestimos/emprestimos.module';
import { EventosModule } from './modules/eventos/eventos.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: 'password',
      database: 'DB_SISTEM_ESTOQUE',
      autoLoadEntities: true,
      synchronize: false,
    }),
    UsersModule,
    AuthModule,
    CategoriasModule,
    EquipamentosModule,
    EmprestimosModule,
    EventosModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
