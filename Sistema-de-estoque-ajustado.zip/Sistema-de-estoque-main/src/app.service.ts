import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHello(): string {
    return 'Sistema Digital de Gestao de Materiais e Eventos da Escola Tecnica';
  }
}
