const state = { equipamentos: [], emprestimos: [], eventos: [] };
const qs = (selector) => document.querySelector(selector);
const api = async (url, options = {}) => {
  const response = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  if (!response.ok) throw new Error(await response.text());
  return response.json();
};
const toast = (text) => {
  const el = qs('#toast');
  el.textContent = text;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2600);
};
const fmtDate = (value) => value ? new Date(value).toLocaleString('pt-BR') : '-';
const badge = (status) => {
  const danger = ['REJEITADO', 'MANUTENCAO'].includes(status);
  const warn = ['PENDENTE', 'EMPRESTADO'].includes(status);
  return '<span class="badge ' + (danger ? 'danger' : warn ? 'warn' : '') + '">' + status + '</span>';
};
async function carregar() {
  try {
    const dados = await Promise.all([api('/equipamentos'), api('/emprestimos'), api('/eventos')]);
    state.equipamentos = dados[0]; state.emprestimos = dados[1]; state.eventos = dados[2];
    render();
  } catch (error) { toast('Nao foi possivel carregar. Verifique o servidor e o MySQL.'); }
}
function render() {
  qs('#totalEquipamentos').textContent = state.equipamentos.length;
  qs('#totalDisponiveis').textContent = state.equipamentos.filter((e) => e.status === 'DISPONIVEL').length;
  qs('#totalEmprestimos').textContent = state.emprestimos.length;
  qs('#totalEventos').textContent = state.eventos.length;
  qs('#equipamentosBody').innerHTML = state.equipamentos.map((e) => '<tr><td>' + e.nome + '</td><td>' + (e.categoria?.nome ?? e.categoriaId) + '</td><td>' + e.codigoPatrimonio + '</td><td>' + badge(e.status) + '</td></tr>').join('') || '<tr><td colspan="4">Nenhum material cadastrado.</td></tr>';
  qs('#emprestimosBody').innerHTML = state.emprestimos.map((e) => '<tr><td>' + (e.equipamento?.nome ?? e.equipamentoId) + '</td><td>' + (e.usuario?.nome ?? e.usuarioId) + '</td><td>' + badge(e.status) + '</td><td>' + fmtDate(e.dataDevolucaoPrevista) + '</td><td class="actions"><button class="secondary" data-approve="' + e.id + '" type="button">Aprovar</button><button class="warn" data-return="' + e.id + '" type="button">Devolver</button></td></tr>').join('') || '<tr><td colspan="5">Nenhum emprestimo registrado.</td></tr>';
  qs('#eventosLista').innerHTML = state.eventos.map((e) => '<article class="event"><strong>' + e.titulo + '</strong><span>' + e.tipo + ' · ' + fmtDate(e.dataInicio) + ' · ' + (e.local ?? 'Sem local') + '</span><p>' + (e.descricao ?? '') + '</p></article>').join('') || '<p>Nenhum evento cadastrado.</p>';
}
document.addEventListener('click', async (event) => {
  const tab = event.target.closest('.tab');
  if (tab) {
    document.querySelectorAll('.tab, .view').forEach((el) => el.classList.remove('active'));
    tab.classList.add('active'); qs('#' + tab.dataset.tab).classList.add('active');
  }
  const approveId = event.target.dataset?.approve;
  if (approveId) {
    const aprovadoPorId = prompt('ID de quem aprovou:');
    if (!aprovadoPorId) return;
    await api('/emprestimos/' + approveId + '/aprovar', { method: 'PATCH', body: JSON.stringify({ aprovadoPorId }) });
    toast('Emprestimo aprovado.'); carregar();
  }
  const returnId = event.target.dataset?.return;
  if (returnId) {
    await api('/emprestimos/' + returnId + '/devolver', { method: 'PATCH' });
    toast('Material devolvido.'); carregar();
  }
});
qs('#refreshBtn').addEventListener('click', carregar);
qs('#equipamentoForm').addEventListener('submit', async (event) => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.target)); await api('/equipamentos', { method: 'POST', body: JSON.stringify(data) }); event.target.reset(); toast('Material cadastrado.'); carregar(); });
qs('#emprestimoForm').addEventListener('submit', async (event) => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.target)); await api('/emprestimos', { method: 'POST', body: JSON.stringify(data) }); event.target.reset(); toast('Solicitacao criada.'); carregar(); });
qs('#eventoForm').addEventListener('submit', async (event) => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.target)); await api('/eventos', { method: 'POST', body: JSON.stringify(data) }); event.target.reset(); toast('Evento adicionado.'); carregar(); });
carregar();
